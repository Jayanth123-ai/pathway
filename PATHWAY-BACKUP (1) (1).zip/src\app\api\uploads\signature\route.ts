import { createHash, createHmac } from "crypto";
import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth";

export async function POST() {
  try { const userId = await requireUser(); const timestamp = Math.floor(Date.now() / 1000); const cloudName = process.env.CLOUDINARY_CLOUD_NAME; const apiKey = process.env.CLOUDINARY_API_KEY; const secret = process.env.CLOUDINARY_API_SECRET;
    if (!cloudName || !apiKey || !secret) return NextResponse.json({ error: "Uploads are not configured yet." }, { status: 503 });
    const folder = `pathway/profiles/${createHash("sha256").update(userId).digest("hex").slice(0, 20)}`; const signature = createHmac("sha1", secret).update(`folder=${folder}&timestamp=${timestamp}`).digest("hex");
    return NextResponse.json({ cloudName, apiKey, folder, timestamp, signature });
  } catch { return NextResponse.json({ error: "Unauthorized" }, { status: 401 }); }
}
