"use client";
import { useState } from "react";
import { useSearchParams } from "next/navigation";
import { Suspense } from "react";
import { createClient } from "@/lib/supabase/client";

export default function SignIn() {
  return <Suspense fallback={null}><SignInForm /></Suspense>;
}

function SignInForm() {
  const [email, setEmail] = useState(""); const [password, setPassword] = useState(""); const [message, setMessage] = useState(""); const [loading, setLoading] = useState(false);
  const params = useSearchParams(); const configured = Boolean(process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY);
  const signIn = async () => { if (!configured) return setMessage("Supabase is not connected yet. Add its URL and publishable key to .env.local, then restart PATHWAY."); setLoading(true); const { error } = await createClient().auth.signInWithPassword({ email, password }); if (error) setMessage(error.message); else window.location.assign("/dashboard"); setLoading(false); };
  const google = async () => { if (!configured) return setMessage("Supabase is not connected yet. Add its URL and publishable key to .env.local, then restart PATHWAY."); const { error } = await createClient().auth.signInWithOAuth({ provider: "google", options: { redirectTo: `${window.location.origin}/auth/callback` } }); if (error) setMessage(error.message); };
  return <main className="auth-page"><a href="/" className="brand"><span className="brand-mark">P</span>PATHWAY</a><div className="auth-card"><span className="eyebrow">WELCOME BACK</span><h1>Your next move<br/><em>is waiting.</em></h1><p>Sign in to continue building your career story.</p>{params.get("setup") === "required" && <p className="coupon-error">Connect Supabase to unlock the dashboard. Your website can still be viewed normally.</p>}<button className="google" onClick={google}><span className="google-logo"><i>G</i></span><span>Continue with Google</span></button><div className="or">OR</div><label>Email address<input value={email} onChange={(e) => setEmail(e.target.value)} type="email" placeholder="you@email.com" /></label><label>Password<input value={password} onChange={(e) => setPassword(e.target.value)} type="password" placeholder="••••••••" /></label><button className="button" disabled={loading} onClick={signIn}>{loading ? "Signing in…" : "Sign in"} <span>→</span></button>{message && <p className="coupon-error">{message}</p>}<span className="auth-switch">New here? <a href="/signup">Create an account</a></span></div></main>;
}
