import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function POST(request: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Please sign in to save a resume." }, { status: 401 });
  const body = await request.json().catch(() => null);
  if (!body || typeof body.title !== "string" || typeof body.resumeType !== "string" || !body.content) return NextResponse.json({ error: "Resume details are incomplete." }, { status: 400 });
  const [{ data: subscription }, { count }] = await Promise.all([supabase.from("subscriptions").select("plan,status").maybeSingle(), supabase.from("resumes").select("id", { count: "exact", head: true })]);
  const subscribed = Boolean(subscription && subscription.plan !== "free" && subscription.status === "active");
  if (!subscribed && (count ?? 0) >= 1) return NextResponse.json({ error: "Your free resume is already saved. Upgrade to create more versions." }, { status: 403 });
  const { error } = await supabase.from("resumes").insert({ user_id: user.id, title: body.title.slice(0, 120), resume_type: body.resumeType.slice(0, 50), content: body.content });
  if (error) return NextResponse.json({ error: "Could not save your resume yet. Please try again." }, { status: 500 });
  return NextResponse.json({ saved: true });
}
