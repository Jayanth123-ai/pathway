import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { SubscribeButton } from "@/components/subscribe-button";
import { CareerWorkspace } from "@/components/career-workspace";

export default async function Dashboard() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const [subscriptionResult, resumeCountResult] = await Promise.all([
    supabase.from("subscriptions").select("plan,status").maybeSingle(),
    supabase.from("resumes").select("id", { count: "exact", head: true }),
  ]);
  const subscription = subscriptionResult.data;
  const plan = subscription?.plan ?? "free";
  const isSubscriber = Boolean(subscription && plan !== "free" && subscription.status === "active");
  const displayName = user?.user_metadata?.full_name || user?.email?.split("@")[0] || "there";
  const resumeCount = resumeCountResult.count ?? 0;

  return <main className="dashboard"><nav><Link className="brand" href="/"><span className="brand-mark">P</span>PATHWAY</Link><details className="account-dock"><summary><span className="account-avatar">{displayName.slice(0, 1).toUpperCase()}</span><span><b>{displayName}</b><small>My dashboard</small></span><i>⌄</i></summary><div className="account-menu"><div><span>PROFILE</span><b>{displayName}</b><small>{user?.email}</small></div><div className="account-menu-stats"><span><b>{resumeCount}</b> resume{resumeCount === 1 ? "" : "s"}</span><span><b>{plan === "free" ? "Free" : plan}</b> plan</span></div><form action="/auth/signout" method="post"><button>Sign out</button></form></div></details></nav><section><span className="eyebrow">YOUR SPACE</span><h1>Welcome, {displayName}</h1><p>Start with the free studio. Your work is yours before you ever need a subscription.</p><CareerWorkspace isSubscriber={isSubscriber} /><div className="plan-picker" id="subscribe"><article><span className="plan">MOMENTUM</span><h2>₹159 / month</h2><p>Unlock exports, unlimited drafts and more career boosts when you’re ready.</p><SubscribeButton plan="momentum" /></article><article><span className="plan">PREMIUM</span><h2>₹499 / month</h2><p>Unlock targeted job matching, cover letters and priority support.</p><SubscribeButton plan="premium" /></article></div></section><footer className="dashboard-footer"><Link className="brand" href="/"><span className="brand-mark">P</span>PATHWAY</Link><div><Link href="/about">About PATHWAY</Link><Link href="/privacy">Privacy Policy</Link><Link href="/founder">About Founder</Link><a href="https://www.instagram.com/varshith_growth/" target="_blank" rel="noreferrer">@varshith_growth ↗</a></div><span>Founded by B. Jayanth Reddy</span></footer></main>;
}
