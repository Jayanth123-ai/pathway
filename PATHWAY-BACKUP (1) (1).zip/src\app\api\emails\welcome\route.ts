import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth";
import { getSupabaseAdmin } from "@/lib/supabase/server";

export async function POST() {
  try { const userId = await requireUser(); const { data: { user } } = await getSupabaseAdmin().auth.admin.getUserById(userId); if (!user?.email) throw new Error("User email is unavailable.");
    if (!process.env.RESEND_API_KEY || !process.env.RESEND_FROM_EMAIL) return NextResponse.json({ error: "Email is not configured yet." }, { status: 503 });
    const response = await fetch("https://api.resend.com/emails", { method: "POST", headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, "Content-Type": "application/json" }, body: JSON.stringify({ from: process.env.RESEND_FROM_EMAIL, to: [user.email], subject: "Welcome to PATHWAY", html: "<h1>Welcome to PATHWAY</h1><p>Your next move starts here. Build your first ATS-ready resume today.</p>" }) });
    if (!response.ok) throw new Error("Could not send welcome email."); return NextResponse.json({ sent: true });
  } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "Unauthorized" }, { status: 400 }); }
}
