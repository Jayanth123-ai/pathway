import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";

export async function proxy(request: NextRequest) {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
  if (!url || !key) {
    const setupUrl = new URL("/signin", request.url);
    setupUrl.searchParams.set("setup", "required");
    return NextResponse.redirect(setupUrl);
  }
  let response = NextResponse.next({ request });
  const supabase = createServerClient(url, key, { cookies: { getAll: () => request.cookies.getAll(), setAll: (items) => { items.forEach(({ name, value }) => request.cookies.set(name, value)); response = NextResponse.next({ request }); items.forEach(({ name, value, options }) => response.cookies.set(name, value, options)); } } });
  const { data: token } = await supabase.auth.getClaims();
  if (!token?.claims && request.nextUrl.pathname.startsWith("/dashboard")) return NextResponse.redirect(new URL("/signin", request.url));
  return response;
}

export const config = { matcher: ["/dashboard/:path*"] };
