import { createHmac, timingSafeEqual } from "crypto";
import { NextResponse } from "next/server";
import { getSupabaseAdmin } from "@/lib/supabase/server";

export async function POST(request: Request) {
  const body = await request.text(); const signature = request.headers.get("x-razorpay-signature") ?? ""; const secret = process.env.RAZORPAY_WEBHOOK_SECRET;
  if (!secret) return NextResponse.json({ error: "Webhook is not configured." }, { status: 503 });
  const expected = createHmac("sha256", secret).update(body).digest("hex");
  if (signature.length !== expected.length || !timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) return NextResponse.json({ error: "Invalid signature" }, { status: 401 });
  const event = JSON.parse(body); const subscription = event.payload?.subscription?.entity;
  if (subscription?.notes?.pathway_user_id) await getSupabaseAdmin().from("subscriptions").upsert({ user_id: subscription.notes.pathway_user_id, razorpay_subscription_id: subscription.id, plan: subscription.notes.pathway_plan, status: subscription.status, current_period_end: subscription.current_end ? new Date(subscription.current_end * 1000).toISOString() : null }, { onConflict: "user_id" });
  return NextResponse.json({ received: true });
}
