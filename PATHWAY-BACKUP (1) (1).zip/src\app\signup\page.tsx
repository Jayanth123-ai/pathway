"use client";
import { useSearchParams } from "next/navigation";
import { useState } from "react";
import { Suspense } from "react";
import { createClient } from "@/lib/supabase/client";

export default function SignUp() {
  return <Suspense fallback={<main className="auth-page"><a href="/" className="brand"><span className="brand-mark">P</span>PATHWAY</a><div className="auth-card">Loading your pathway…</div></main>}><SignUpForm /></Suspense>;
}

function SignUpForm() {
  const [submitted, setSubmitted] = useState(false); const [name, setName] = useState(""); const [email, setEmail] = useState(""); const [password, setPassword] = useState(""); const [code, setCode] = useState(""); const [couponMessage, setCouponMessage] = useState(""); const [loading, setLoading] = useState(false); const params = useSearchParams(); const plan = params.get("plan") ?? "explorer";
  const applyCoupon = () => setCouponMessage(code.trim().toUpperCase() === "JAY" ? "50% off your first month has been applied!" : "That code is not valid. Please try again.");
  const signUp = async () => { setLoading(true); const { error } = await createClient().auth.signUp({ email, password, options: { data: { full_name: name }, emailRedirectTo: `${window.location.origin}/auth/callback` } }); if (error) setCouponMessage(error.message); else { setSubmitted(true); } setLoading(false); };
  const google = async () => { const { error } = await createClient().auth.signInWithOAuth({ provider: "google", options: { redirectTo: `${window.location.origin}/auth/callback` } }); if (error) setCouponMessage(error.message); };
  return <main className="auth-page"><a href="/" className="brand"><span className="brand-mark">P</span>PATHWAY</a><div className="auth-card"><span className="eyebrow">START YOUR PATHWAY · {plan.toUpperCase()}</span><h1>Let’s make<br/><em>it happen.</em></h1><p>Create an account, choose your direction, and start with a stronger first impression.</p><div className="promo-field"><label>Promo code<input value={code} onChange={(event) => setCode(event.target.value)} placeholder="Enter your code" /></label><button type="button" onClick={applyCoupon}>Apply</button></div>{couponMessage && <p className={couponMessage.startsWith("50") ? "coupon-success" : "coupon-error"}>{couponMessage}</p>}<button className="google" onClick={google}><span className="google-logo"><i>G</i></span><span>Continue with Google</span></button><div className="or">OR</div><label>Full name<input value={name} onChange={(e) => setName(e.target.value)} type="text" placeholder="Your name" /></label><label>Email address<input value={email} onChange={(e) => setEmail(e.target.value)} type="email" placeholder="you@email.com" /></label><label>Create password<input value={password} onChange={(e) => setPassword(e.target.value)} type="password" placeholder="8+ characters" /></label><button className="button" disabled={loading} onClick={signUp}>{loading ? "Creating account…" : "Create my account"} <span>→</span></button>{submitted && <p className="auth-note">Check your email to confirm your PATHWAY account.</p>}<span className="auth-switch">Already have an account? <a href="/signin">Sign in</a></span></div></main>;
}
