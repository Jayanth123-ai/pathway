create extension if not exists "pgcrypto";

create type public.resume_type as enum ('chronological', 'functional', 'hybrid', 'targeted', 'academic');
create type public.plan_tier as enum ('free', 'momentum', 'trajectory');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text, avatar_url text, role text default 'user' check (role in ('user','admin')),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.resumes (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null default 'Untitled resume', resume_type public.resume_type not null default 'chronological',
  content jsonb not null default '{}'::jsonb, template_key text not null default 'pathway-classic',
  target_role text, is_archived boolean not null default false, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.resume_versions (
  id uuid primary key default gen_random_uuid(), resume_id uuid not null references public.resumes(id) on delete cascade,
  content jsonb not null, created_at timestamptz not null default now()
);
create table public.subscriptions (
  id uuid primary key default gen_random_uuid(), user_id uuid not null unique references public.profiles(id) on delete cascade,
  plan public.plan_tier not null default 'free', razorpay_subscription_id text unique, status text not null default 'active', current_period_end timestamptz, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.ai_usage (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade,
  feature text not null, input_tokens integer not null default 0, output_tokens integer not null default 0, created_at timestamptz not null default now()
);
create table public.payments (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade,
  razorpay_payment_id text unique, razorpay_subscription_id text, amount integer, currency text not null default 'INR', status text not null, created_at timestamptz not null default now()
);
create or replace function public.create_profile_for_user() returns trigger language plpgsql security definer set search_path = public as $$ begin insert into public.profiles (id, full_name) values (new.id, coalesce(new.raw_user_meta_data ->> 'full_name', '')); insert into public.subscriptions (user_id) values (new.id); return new; end; $$;
revoke all on function public.create_profile_for_user() from public;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.create_profile_for_user();
create index resumes_user_updated_idx on public.resumes(user_id, updated_at desc);
create index ai_usage_user_created_idx on public.ai_usage(user_id, created_at desc);

alter table public.profiles enable row level security;
alter table public.resumes enable row level security;
alter table public.resume_versions enable row level security;
alter table public.subscriptions enable row level security;
alter table public.ai_usage enable row level security;
alter table public.payments enable row level security;

create policy "profiles owner read" on public.profiles for select to authenticated using ((select auth.uid()) = id);
create policy "profiles owner update" on public.profiles for update to authenticated using ((select auth.uid()) = id) with check ((select auth.uid()) = id);
create policy "resumes owner access" on public.resumes for all to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "versions owner access" on public.resume_versions for all to authenticated using (exists (select 1 from public.resumes r where r.id = resume_id and r.user_id = (select auth.uid()))) with check (exists (select 1 from public.resumes r where r.id = resume_id and r.user_id = (select auth.uid())));
create policy "subscriptions owner read" on public.subscriptions for select to authenticated using ((select auth.uid()) = user_id);
create policy "usage owner read" on public.ai_usage for select to authenticated using ((select auth.uid()) = user_id);
create policy "payments owner read" on public.payments for select to authenticated using ((select auth.uid()) = user_id);
