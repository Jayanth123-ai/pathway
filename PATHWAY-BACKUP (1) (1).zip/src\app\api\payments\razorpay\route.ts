import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUser } from "@/lib/auth";

const schema = z.object({ plan: z.enum(["momentum", "premium"]), coupon: z.string().trim().max(30).optional() });

export async function POST(request: Request) {
  try {
    const userId = await requireUser();
    const { plan, coupon } = schema.parse(await request.json());
    const planId = plan === "momentum" ? process.env.RAZORPAY_MOMENTUM_PLAN_ID : process.env.RAZORPAY_PREMIUM_PLAN_ID;
    if (!planId || !process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) return NextResponse.json({ error: "Payments are not configured yet." }, { status: 503 });
    const offerId = coupon?.toUpperCase() === "JAY" ? process.env.RAZORPAY_JAY_OFFER_ID : undefined;
    const authorization = Buffer.from(`${process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID}:${process.env.RAZORPAY_KEY_SECRET}`).toString("base64");
    const response = await fetch("https://api.razorpay.com/v1/subscriptions", { method: "POST", headers: { Authorization: `Basic ${authorization}`, "Content-Type": "application/json" }, body: JSON.stringify({ plan_id: planId, total_count: 120, customer_notify: true, ...(offerId ? { offer_id: offerId } : {}), notes: { pathway_user_id: userId, pathway_plan: plan } }) });
    const data = await response.json();
    if (!response.ok) return NextResponse.json({ error: data.error?.description ?? "Could not create the test subscription." }, { status: 400 });
    return NextResponse.json({ subscriptionId: data.id, razorpayKey: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID });
  } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "Invalid payment request." }, { status: 400 }); }
}
