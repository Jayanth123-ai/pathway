import { createHmac, timingSafeEqual } from "crypto";
import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
import { getSupabaseAdmin } from "@/lib/supabase/server";

const schema = z.object({ razorpay_payment_id: z.string().min(1), razorpay_subscription_id: z.string().min(1), razorpay_signature: z.string().min(1) });
export async function POST(request: Request) {
  try { const userId = await requireUser(); const data = schema.parse(await request.json()); const secret = process.env.RAZORPAY_KEY_SECRET; if (!secret) throw new Error("Payments are not configured."); const expected = createHmac("sha256", secret).update(`${data.razorpay_payment_id}|${data.razorpay_subscription_id}`).digest("hex");
    if (expected.length !== data.razorpay_signature.length || !timingSafeEqual(Buffer.from(expected), Buffer.from(data.razorpay_signature))) return NextResponse.json({ error: "Invalid payment signature." }, { status: 400 });
    await getSupabaseAdmin().from("payments").upsert({ user_id: userId, razorpay_payment_id: data.razorpay_payment_id, razorpay_subscription_id: data.razorpay_subscription_id, status: "authorized" }, { onConflict: "razorpay_payment_id" });
    return NextResponse.json({ verified: true });
  } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "Invalid payment." }, { status: 400 }); }
}
