import { NextResponse } from "next/server";
import { z } from "zod";

const requestSchema = z.object({ resumeType: z.enum(["chronological", "functional", "hybrid", "targeted", "academic"]), role: z.string().min(2).max(120), experience: z.string().min(20).max(12000), jobDescription: z.string().max(12000).optional() });

export async function POST(request: Request) {
  try {
    const input = requestSchema.parse(await request.json());
    if (!process.env.OPENAI_API_KEY) return NextResponse.json({ error: "AI is not configured yet. Add OPENAI_API_KEY to .env.local." }, { status: 503 });
    // The API key remains server-only. Add the OpenAI SDK call here after selecting a model.
    return NextResponse.json({ message: "AI endpoint is ready for the OpenAI integration.", input });
  } catch { return NextResponse.json({ error: "Please provide a valid resume request." }, { status: 400 }); }
}
